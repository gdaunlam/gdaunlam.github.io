package OIA.Grafos.coloring.order;

import OIA.Grafos.Grapth;

public interface OrderMethod {
	
	public Order generateOrder(Grapth graph);

}
