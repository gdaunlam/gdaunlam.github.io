package OIA.Grafos.coloring.order;

public class Order {
	
	private Integer[] order;
	
	public Order(Integer[] order) {
		this.order = order;
	}
	
	public Integer[] getOrder() {
		return order;
	}

}
