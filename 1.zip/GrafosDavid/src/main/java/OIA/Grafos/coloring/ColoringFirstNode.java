package OIA.Grafos.coloring;

import OIA.Grafos.Grapth;
import OIA.Grafos.coloring.order.Order;

public class ColoringFirstNode implements ColoringMethod {

	@Override
		public Coloring paint(Grapth graph, Order order) {
			Coloring coloring = new Coloring(new int[0]) ;
			
			// TODO: Implement me!
			
			return coloring;
		}

}
