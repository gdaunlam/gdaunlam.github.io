package OIA.Grafos;

public class Node {
	double number;
	double cost;

	public Node(double number, double cost) {
		this.number = number;
		this.cost = cost;
	}
}
