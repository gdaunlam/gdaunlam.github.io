package grafos.coloreo.orden;

import grafos.Grafo;

public interface MetodoOrdenamiento {
	public Orden generarOrden(Grafo g);
}
