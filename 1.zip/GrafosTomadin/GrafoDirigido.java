package grafos;

public class GrafoDirigido extends Grafo {

	public GrafoDirigido(int cantNodos) {
		super(cantNodos);
	}

}
