package unlam.progava.oia;

import java.io.File;

import org.junit.Test;

import junitx.framework.FileAssert;

public class EnunciadoTest {

	EjercicioOIA ejercicio = new EjercicioOIA();
	
	@Test
	public void enunciado0() {
		ejecutarCaso(0);
	}
	
	@Test
	public void enunciado1() {
		ejecutarCaso(1);
	}
	
	@Test
	public void enunciado2() {
		ejecutarCaso(2);
	}
	
	@Test
	public void enunciado3() {
		ejecutarCaso(3);
	}
	
	@Test
	public void enunciado4() {
		ejecutarCaso(4);
	}
	
	@Test
	public void enunciado6() {
		ejecutarCaso(6);
	}
	
	@Test
	public void enunciado7() {
		ejecutarCaso(7);
	}
	
	public void ejecutarCaso(int numCaso) {	
		String caso = "0" + numCaso;
		
		String in = "src/unlam/progava/oia/in/" + caso + ".in";
		String expected = "src/unlam/progava/oia/expected/" + caso + ".out";
		String actual = "src/unlam/progava/oia/out/" + caso + ".out";
		
		ejercicio.leer(in);
		ejercicio.resolver();
		ejercicio.escribir(actual);
		
		FileAssert.assertEquals(new File(expected), new File(actual));
	}
	
}
