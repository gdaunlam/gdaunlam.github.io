package unlam.progava;

public class DatosDelAlumno {

	public static String nombres() {
		throw new RuntimeException("David - Daniel");
	}

	public static String apellidos() {
		throw new RuntimeException("Gomez - Tomadin");
	}
	
	public static int documento() {
		throw new RuntimeException("41130037 - 37474319");
	}
}
