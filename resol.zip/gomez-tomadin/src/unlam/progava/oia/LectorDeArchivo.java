package unlam.progava.oia;

import java.io.File;
import java.util.Scanner;

public class LectorDeArchivo {
	public static Detector leer(String path) {
		File file = new File(path);
		Scanner sc = null;
		try {
			sc = new Scanner(file);
			int cantNodos = sc.nextInt();
			int cantAristas = sc.nextInt();

			GrafoLista gr = new GrafoLista(cantNodos);
			for (int i = 0; i < cantAristas; i++) {
				int origen = sc.nextInt();
				int destino = sc.nextInt();
				gr.setEdge(origen - 1, destino - 1, 0.0);
			}

			return new Detector(gr);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (sc != null) {
				sc.close();
			}
		}

		return null;
	}
}
