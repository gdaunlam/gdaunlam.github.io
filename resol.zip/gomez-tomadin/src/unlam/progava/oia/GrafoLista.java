package unlam.progava.oia;
import java.util.LinkedList;
import java.util.List;

public class GrafoLista {
	private List<Nodo>[] grapth;

	public GrafoLista(int lenght) {
		this.grapth = new List[lenght];
		for (int i = 0; i < lenght; i++) {
			this.grapth[i] = new LinkedList<Nodo>();
		}
	}

	public void setEdge(int origin, int destination, Double value) {
		for (Nodo node : this.grapth[origin]) {
			if (node.number == destination) {
				node.cost = value;
				return;
			}
		}
		this.grapth[origin].add(new Nodo(destination, value));
	}

	public Double getEdge(int origin, int destination) {
		for (Nodo node : this.grapth[origin]) {
			if (node.number == destination) {
				return node.cost;
			}
		}
		return null;
	}

	public int getNodes() {
		return grapth.length;
	}

	public Double[] getAdjacents(int origin) {
		Double[] adjascents = new Double[this.grapth.length];
		for (Nodo node : this.grapth[origin]) {
			adjascents[(int)node.number] = node.cost;
		}
		
		return adjascents;
	}
}
