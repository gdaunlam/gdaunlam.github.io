package unlam.progava.oia;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class EscritorDeArchivo {

	private static void printProp(List<Integer> prop, FileWriter fw) throws IOException {
		fw.write("\n");
		String prop3 = "";
		if (prop.size() == 0) {
			prop3 = "0";
		}
		for (Integer nodo : prop) {
			prop3 += (nodo + 1) + " ";
		}
		fw.write(prop3.trim());
	}

	public static void escribir(Deteccion deteccion, String path) {
		File file = new File(path);
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
			fw.write(deteccion.getResultado());

			if (deteccion.getResultado() == "SI") {
				fw.write(" " + (deteccion.getProp1().get(0) + 1));
			} else {
				printProp(deteccion.getProp1(), fw);
				printProp(deteccion.getProp2(), fw);
				printProp(deteccion.getProp3(), fw);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
