package unlam.progava.oia;

import java.util.LinkedList;
import java.util.List;

public class Detector {
	private GrafoLista gr;

	public Detector(GrafoLista gr) {
		super();
		this.gr = gr;
	}

	public Deteccion detectar() {
		List<Integer> noVisitedKeys = new LinkedList<Integer>();
		List<Integer> nodosConMasDeUnArco = new LinkedList<Integer>();
		List<Integer> nodosSinArco = new LinkedList<Integer>();
		int[] countOfVisits = new int[this.gr.getNodes()];

		int initial = 0;
		noVisitedKeys.add(initial);

		while (noVisitedKeys.size() > 0) {
			int actual = noVisitedKeys.get(0);
			Double[] adjacents = this.gr.getAdjacents(actual);
			for (int i = 0; i < adjacents.length; i++) {
				if (adjacents[i] != null) {
					if (countOfVisits[i] == 0 && i != initial) {
						noVisitedKeys.add(i);
					}
					countOfVisits[i]++;
				}
			}
			noVisitedKeys.remove(0);
		}

		for (int i = 0; i < countOfVisits.length; i++) {
			if (countOfVisits[i] > 1) {
				nodosConMasDeUnArco.add(i);
			}
			if (countOfVisits[i] == 0) {
				nodosSinArco.add(i);
			}
		}

		boolean isArgbol = nodosSinArco.size() == 1 && nodosConMasDeUnArco.size() == 0;
		nodosSinArco = isArgbol ? nodosSinArco : new LinkedList<Integer>();
		Deteccion deteccion = new Deteccion(isArgbol ? "SI" : "NO", nodosSinArco, nodosConMasDeUnArco,
				new LinkedList<Integer>());
		return deteccion;
	}
}
