package unlam.progava.oia;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EscritorDeArchivo {
	public static void escribir(Deteccion deteccion, String path) {
		File file = new File(path);
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
			fw.write(deteccion.getResultado());

			
			fw.write("\n");
			String prop1 = "";
			if (deteccion.getProp1().size() == 0) {
				prop1 = "0";
			}
			for (Integer nodo : deteccion.getProp1()) {
				prop1 = (nodo +1) + " ";
			}
			fw.write(prop1.trim());
			
			
			fw.write("\n");
			String prop2 = "";
			if (deteccion.getProp2().size() == 0) {
				prop2 = "0";
			}
			for (Integer nodo : deteccion.getProp2()) {
				prop2 = (nodo +1) + " ";
			}
			fw.write(prop2.trim());

			
			fw.write("\n");
			String prop3 = "";
			if (deteccion.getProp3().size() == 0) {
				prop3 = "0";
			}
			for (Integer nodo : deteccion.getProp3()) {
				prop3 = (nodo +1) + " ";
			}
			fw.write(prop3.trim());
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
