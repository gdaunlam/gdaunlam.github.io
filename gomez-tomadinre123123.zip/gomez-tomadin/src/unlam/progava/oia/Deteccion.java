package unlam.progava.oia;

import java.util.List;

public class Deteccion {
	private String resultado;

	private List<Integer> prop1;
	private List<Integer> prop2;
	private List<Integer> prop3;

	public Deteccion(String resultado, List<Integer> prop1, List<Integer> prop2, List<Integer> prop3) {
		super();
		this.resultado = resultado;
		this.prop1 = prop1;
		this.prop2 = prop2;
		this.prop3 = prop3;
	}

	public String getResultado() {
		return resultado;
	}

	public List<Integer> getProp1() {
		return prop1;
	}

	public List<Integer> getProp2() {
		return prop2;
	}

	public List<Integer> getProp3() {
		return prop3;
	}
}
