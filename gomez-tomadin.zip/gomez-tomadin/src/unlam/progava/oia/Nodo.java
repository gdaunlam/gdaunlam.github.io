package unlam.progava.oia;

public class Nodo {
	double number;
	double cost;

	public Nodo(double number, double cost) {
		this.number = number;
		this.cost = cost;
	}
}
