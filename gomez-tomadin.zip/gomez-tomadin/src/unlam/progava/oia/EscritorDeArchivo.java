package unlam.progava.oia;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class EscritorDeArchivo {
	public static void escribir(Deteccion deteccion, String path) {
		File file = new File(path);
		FileWriter fw = null;
		try {
			fw = new FileWriter(file);
			
			fw.write(deteccion.getResultado());
			
			String prop1 = deteccion.getProp1().size()+"";
			for (Integer nodo : deteccion.getProp1()) {
				prop1 += nodo + " ";
			}
			fw.write(prop1);
			
			String prop2 = deteccion.getProp2().size()+"";
			for (Integer nodo : deteccion.getProp2()) {
				prop2 += nodo + " ";
			}
			fw.write(prop2);
			
			String prop3 = deteccion.getProp3().size()+"";
			for (Integer nodo : deteccion.getProp3()) {
				prop3 += nodo + " ";
			}
			fw.write(prop3);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
